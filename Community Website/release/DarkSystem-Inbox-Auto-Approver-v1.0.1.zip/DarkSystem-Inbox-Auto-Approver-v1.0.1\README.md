# DarkSystem Inbox Auto Approver

Extension Chrome/Edge ini membantu anggota komunitas membuka setiap item inbox distribusi di `https://darksystem.id/clans/inbox`, menekan tombol `Lihat TKP`, lalu mengklik tombol `Setuju` dan `Konfirmasi` untuk item yang masih menunggu.

## Fitur

- Scan otomatis semua inbox distribusi yang terdeteksi di halaman inbox.
- Membuka detail inbox satu per satu.
- Menekan tombol `Lihat TKP` secara otomatis.
- Menekan tombol `Setuju`, lalu lanjut menekan `Konfirmasi` bila popup konfirmasi muncul.
- Auto scroll halaman inbox dan mencoba tombol `Muat lebih banyak` agar daftar inbox termuat lebih lengkap.
- Menyimpan progres sederhana supaya user bisa melihat jumlah item yang berhasil diproses.
- Menyediakan popup `Mulai`, `Stop`, dan `Reset`.
- Menampilkan panel status kecil di halaman DarkSystem saat automation sedang jalan.

## Struktur File

- `manifest.json`
- `popup.html`
- `popup.css`
- `popup.js`
- `content.js`
- `README.md`

## Cara Pasang di Chrome / Edge

1. Extract file ZIP extension ini ke folder biasa, misalnya `DarkSystem Auto Approver`.
2. Buka browser Chrome atau Edge.
3. Masuk ke halaman extension:
   - Chrome: `chrome://extensions/`
   - Edge: `edge://extensions/`
4. Aktifkan `Developer mode`.
5. Klik `Load unpacked`.
6. Pilih folder hasil extract yang berisi file `manifest.json`.
7. Setelah berhasil, icon extension akan muncul di browser.

## Cara Pakai

1. Login dulu ke akun DarkSystem masing-masing anggota.
2. Buka website `https://darksystem.id/clans/inbox` atau halaman DarkSystem mana saja.
3. Klik icon extension `DarkSystem Auto Approver`.
4. Atur `Delay antar aksi` bila perlu. Default `2` detik.
5. Klik tombol `Mulai`.
6. Jika sedang berada di luar domain `darksystem.id`, extension akan otomatis mengarahkan tab ke halaman inbox.
7. Biarkan tab tetap terbuka sampai semua item selesai diproses.

## Catatan Penting

- Extension ini bekerja untuk akun yang sedang login pada browser tersebut.
- Setiap anggota harus menjalankan extension pada akun masing-masing jika persetujuan memang harus dilakukan per akun.
- Jangan menutup tab yang sedang dipakai automation sampai proses selesai.
- Kalau ada perubahan tampilan HTML dari website DarkSystem, selector mungkin perlu disesuaikan lagi.
- Saya belum bisa menguji langsung ke website target dari lingkungan ini, jadi kalau ada tombol atau teks yang sedikit berbeda, kita bisa revisi selector dengan cepat.

## Tombol di Popup

- `Mulai`: mulai scan inbox dan jalankan automation.
- `Stop`: hentikan proses yang sedang berjalan.
- `Reset`: hapus status proses sebelumnya.

## Troubleshooting

### Automation tidak jalan

- Pastikan extension sudah di-load tanpa error.
- Pastikan akun sudah login ke DarkSystem.
- Coba refresh halaman `https://darksystem.id/clans/inbox`, lalu klik `Mulai` lagi.

### Tombol `Setuju` tidak terklik

- Bisa jadi teks tombol atau struktur HTML di halaman berbeda dari screenshot.
- Buka `Inspect Element`, cek teks tombolnya, lalu sesuaikan script di `content.js`.

### Inbox yang ditemukan tidak lengkap

- Extension mencoba scroll otomatis dan menekan tombol `Muat lebih banyak` agar semua item inbox termuat.
- Kalau website memakai pagination atau lazy load yang berbeda, logika scan bisa ditambah lagi.
